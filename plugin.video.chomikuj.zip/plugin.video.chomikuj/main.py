import sys
import os
import re
import json
import urllib.request
import urllib.parse
import urllib.error
import http.cookiejar
from html.parser import HTMLParser
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_HANDLE = int(sys.argv[1]) if len(sys.argv) > 1 and sys.argv[1].isdigit() else -1
BASE_URL = sys.argv[0] if len(sys.argv) > 0 else ""
CHOMIKUJ_URL = "https://chomikuj.pl"

PROFILE_DIR = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
if not xbmcvfs.exists(PROFILE_DIR):
    xbmcvfs.mkdirs(PROFILE_DIR)

COOKIE_FILE = os.path.join(PROFILE_DIR, 'cookies.lwp')
cookie_jar = http.cookiejar.LWPCookieJar(COOKIE_FILE)
if os.path.exists(COOKIE_FILE):
    try:
        cookie_jar.load(ignore_discard=True, ignore_expires=True)
    except Exception:
        pass

USER_AGENT = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
VIDEO_EXTENSIONS = ('.mp4', '.avi', '.mkv', '.mov', '.flv', '.wmv', '.webm', '.ts', '.m4v', '.mpg', '.mpeg', '.vob')

IGNORED_NAMES = {
    'pobierz', 'download', 'ściągnij', 'zapisz', 'play', 'odtwórz', 'oglądaj',
    'zgłoś', 'zaloguj', 'wyloguj', 'rejestracja', 'kontakt', 'pomoc', 'regulamin',
    'polityka prywatności', 'politykaprywatnosci', 'zobacz więcej', 'więcej',
    'edytuj', 'usuń', 'przenieś', 'zmień nazwę', 'nowy folder', 'wideo', 'video',
    'audio', 'obraz', 'chomikuj', 'reklama', 'napisz do nas', 'zgłoś naruszenie'
}

SYSTEM_EXCLUDE_PREFIXES = (
    '/action/', '/kontakt', '/pomoc', '/regulamin', '/politykaprywatnosci',
    '/abuse', '/login', '/logout', '/rejestracja', '/oplaty', '/faq', '/terms', '/privacy'
)


class NoRedirectHandler(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


opener_redirect = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar))
opener_no_redirect = urllib.request.build_opener(urllib.request.HTTPCookieProcessor(cookie_jar), NoRedirectHandler())


def build_url(query):
    return f"{BASE_URL}?{urllib.parse.urlencode(query)}"


def request(url, data=None, headers=None, follow_redirects=True, max_bytes=1000000, timeout=15):
    req_headers = {
        'User-Agent': USER_AGENT,
        'Accept-Language': 'pl-PL,pl;q=0.9,en;q=0.8'
    }
    if headers:
        req_headers.update(headers)

    encoded_data = None
    if data is not None:
        if isinstance(data, dict):
            encoded_data = urllib.parse.urlencode(data).encode('utf-8')
            if 'Content-Type' not in req_headers:
                req_headers['Content-Type'] = 'application/x-www-form-urlencoded; charset=UTF-8'
        elif isinstance(data, str):
            encoded_data = data.encode('utf-8')

    req = urllib.request.Request(url, data=encoded_data, headers=req_headers)
    current_opener = opener_redirect if follow_redirects else opener_no_redirect

    try:
        with current_opener.open(req, timeout=timeout) as resp:
            try:
                cookie_jar.save(ignore_discard=True, ignore_expires=True)
            except Exception:
                pass

            content_type = resp.headers.get('Content-Type', '').lower()
            if 'video/' in content_type or 'octet-stream' in content_type:
                return resp.getcode(), resp.geturl(), resp.headers

            body = resp.read(max_bytes).decode('utf-8', errors='ignore')
            return resp.getcode(), body, resp.headers

    except urllib.error.HTTPError as e:
        try:
            cookie_jar.save(ignore_discard=True, ignore_expires=True)
        except Exception:
            pass

        if e.code in (301, 302, 303, 307):
            loc = e.headers.get('Location', '')
            if follow_redirects and loc:
                target = urllib.parse.urljoin(url, loc)
                return request(target, follow_redirects=True, timeout=timeout)
            return e.code, loc, e.headers

        try:
            body = e.read(50000).decode('utf-8', errors='ignore')
        except Exception:
            body = ''
        return e.code, body, e.headers

    except Exception as e:
        xbmc.log(f"[Chomikuj] Błąd połączenia ({url}): {e}", xbmc.LOGERROR)
        return None, '', {}


def get_verification_token(html):
    m = re.search(r'name=["\']__RequestVerificationToken["\'][^>]*value=["\']([^"\']+)["\']', html)
    if not m:
        m = re.search(r'value=["\']([^"\']+)["\'][^>]*name=["\']__RequestVerificationToken["\']', html)
    return m.group(1) if m else ''


def login():
    username = ADDON.getSetting('username')
    password = ADDON.getSetting('password')

    if not username or not password:
        return set_credentials_dialog()

    code, html, _ = request(CHOMIKUJ_URL)
    token = get_verification_token(html)

    payload = {
        'Login': username,
        'Password': password,
        'RememberMe': 'true'
    }
    if token:
        payload['__RequestVerificationToken'] = token

    login_url = f"{CHOMIKUJ_URL}/action/Login/Login"
    code, resp_html, _ = request(login_url, data=payload)

    if username.lower() in resp_html.lower() or "wyloguj" in resp_html.lower():
        xbmcgui.Dialog().notification("Chomikuj", f"Zalogowano: {username}", xbmcgui.NOTIFICATION_INFO, 2000)
        return True
    else:
        xbmcgui.Dialog().notification("Chomikuj", "Błąd logowania. Sprawdź hasło!", xbmcgui.NOTIFICATION_ERROR, 3500)
        return False


def set_credentials_dialog():
    dialog = xbmcgui.Dialog()
    current_user = ADDON.getSetting('username')

    new_user = dialog.input("Podaj login / nazwę użytkownika", defaultt=current_user)
    if not new_user:
        return False

    new_pass = dialog.input("Podaj hasło do Chomikuj", option=xbmcgui.ALPHANUM_HIDE_INPUT)
    if not new_pass:
        return False

    ADDON.setSetting('username', new_user.strip())
    ADDON.setSetting('password', new_pass.strip())
    return login()


def get_cookie_header():
    return "; ".join([f"{c.name}={c.value}" for c in cookie_jar])


def set_item_video_info(list_item, title):
    try:
        info_tag = list_item.getVideoInfoTag()
        info_tag.setTitle(title)
    except Exception:
        list_item.setInfo('video', {'title': title})


def main_menu():
    username = ADDON.getSetting('username')
    status_label = f"👤 Zalogowany: {username}" if username else "🔑 Zaloguj / Wpisz dane konta"

    items = [
        (status_label, build_url({'action': 'set_login'}), False),
        ("📁 Mój Chomik (Moje pliki)", build_url({'action': 'my_files'}), True),
        ("⚙️ Ustawienia wtyczki", build_url({'action': 'open_settings'}), False)
    ]
    for label, url, is_folder in items:
        list_item = xbmcgui.ListItem(label=label)
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=url, listitem=list_item, isFolder=is_folder)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def clean_filename_from_url(url):
    unquoted = urllib.parse.unquote(url).split('?')[0].split('#')[0]
    base = os.path.basename(unquoted)
    base = re.sub(r'\([a-zA-Z0-9_-]+\)$', '', base).strip()

    m1 = re.match(r'^(.*?\.[a-zA-Z0-9]{2,4}),\d+', base)
    if m1:
        return m1.group(1).strip()

    m2 = re.match(r'^(.*?),(\d+)(\.[a-zA-Z0-9]{2,4})$', base)
    if m2:
        return f"{m2.group(1).strip()}{m2.group(3)}"

    base = re.sub(r',\d+$', '', base).strip()
    return base


class ChomikujFolderParser(HTMLParser):
    def __init__(self, current_base_path, current_page):
        super().__init__()
        self.current_base_path = current_base_path.rstrip('/')
        self.current_page = current_page
        self.unquoted_curr = urllib.parse.unquote(self.current_base_path).lower()
        self.prefix = self.unquoted_curr + '/'

        self.subfolders = {}
        self.files = {}
        self.thumbs_by_id = {}
        self.last_img_thumb = ''
        self.has_next_page = False
        self.next_page_url = ''

        self.in_a = False
        self.current_href = ''
        self.current_attrs = {}
        self.text_parts = []
        self.last_container_file_id = ''

    def handle_starttag(self, tag, attrs):
        attr_dict = dict(attrs)

        if 'data-fileid' in attr_dict:
            self.last_container_file_id = attr_dict['data-fileid']
            self.last_img_thumb = ''
        elif 'rel' in attr_dict and attr_dict.get('rel', '').isdigit():
            self.last_container_file_id = attr_dict['rel']

        if tag == 'img':
            src = attr_dict.get('src') or attr_dict.get('data-original') or attr_dict.get('data-src') or ''
            if src:
                src_lower = src.lower()
                skip_words = ('/icons/', 'extension_', 'folder.gif', 'avatar', 'layout', 'blank.gif', 'pixel.gif', 'logo')
                if not any(sw in src_lower for sw in skip_words):
                    if any(k in src_lower for k in ('thumbnail', 'img.chomikuj.pl', 'thumb')):
                        if src.startswith('//'):
                            src = 'https:' + src
                        elif src.startswith('/'):
                            src = f"{CHOMIKUJ_URL}{src}"
                        self.last_img_thumb = src
                        m_fid = re.search(r'fileid=(\d+)', src_lower)
                        if m_fid:
                            self.thumbs_by_id[m_fid.group(1)] = src

        style = attr_dict.get('style', '')
        if 'thumbnail' in style.lower() or 'img.chomikuj.pl' in style.lower():
            m_bg = re.search(r'url\([\'"]?(https?://[^)]+|//[^)]+|/[^)]+)[\'"]?\)', style, re.I)
            if m_bg:
                bg_url = m_bg.group(1)
                if bg_url.startswith('//'):
                    bg_url = 'https:' + bg_url
                elif bg_url.startswith('/'):
                    bg_url = f"{CHOMIKUJ_URL}{bg_url}"
                self.last_img_thumb = bg_url
                m_fid = re.search(r'fileid=(\d+)', bg_url.lower())
                if m_fid:
                    self.thumbs_by_id[m_fid.group(1)] = bg_url

        if tag == 'a':
            self.in_a = True
            self.current_href = attr_dict.get('href', '')
            self.current_attrs = attr_dict
            self.text_parts = []

            cls = attr_dict.get('class', '').lower()
            rel = attr_dict.get('rel', '').lower()
            if ('pagenext' in cls or (cls == 'next' and 'disabled' not in cls) or rel == 'next'):
                if self.current_href and not self.current_href.startswith('#') and not self.current_href.startswith('javascript:'):
                    self.has_next_page = True
                    self.next_page_url = self.current_href

    def handle_data(self, data):
        if self.in_a:
            self.text_parts.append(data)

    def handle_endtag(self, tag):
        if tag == 'a' and self.in_a:
            self.in_a = False
            href = self.current_href.strip()
            if not href or href.startswith(('#', 'javascript:', 'mailto:')):
                return

            if href.startswith(('http://', 'https://', '//')):
                full_url = 'https:' + href if href.startswith('//') else href
                parsed = urllib.parse.urlparse(full_url)
                if 'chomikuj.pl' in parsed.netloc.lower():
                    href = parsed.path
                else:
                    return

            href_lower = href.lower()
            if any(href_lower.endswith(ext) for ext in ('.aspx', '.asp', '.php', '.html', '.htm')):
                return
            if any(href_lower.startswith(bad) for bad in SYSTEM_EXCLUDE_PREFIXES):
                return

            if not href.startswith('/'):
                href = f"{self.current_base_path}/{href}"

            raw_text = "".join(self.text_parts).strip()
            text = " ".join(raw_text.split())

            unquoted_href = urllib.parse.unquote(href)
            unquoted_href_lower = unquoted_href.lower()
            title_attr = self.current_attrs.get('title', '').strip()

            check_str = f"{unquoted_href_lower} {title_attr.lower()} {text.lower()}"
            is_vid = any(ext in check_str for ext in VIDEO_EXTENSIONS) or '(video)' in check_str

            if not is_vid:
                target_page_num = self.current_page + 1
                m_page = re.search(r',(\d+)(?:[#\?].*)?$', unquoted_href)
                if m_page and int(m_page.group(1)) == target_page_num:
                    self.has_next_page = True
                    self.next_page_url = href
                elif text.strip() == str(target_page_num):
                    self.has_next_page = True
                    self.next_page_url = href
                elif any(w in text.lower() for w in ('następna', 'dalej', 'next', '>>', '»')):
                    self.has_next_page = True
                    self.next_page_url = href

            if is_vid and href.startswith('/'):
                clean_href = unquoted_href_lower.split('?')[0].split('#')[0]
                norm_prefix = urllib.parse.unquote_plus(self.prefix).lower()
                norm_href = urllib.parse.unquote_plus(clean_href).lower()

                if not norm_href.startswith(norm_prefix):
                    return

                remainder = norm_href[len(norm_prefix):].strip('/')
                if '/' in remainder:
                    return

                file_id = self.current_attrs.get('data-fileid') or self.last_container_file_id
                if not file_id:
                    m = re.search(r',(\d+)', href)
                    if m:
                        file_id = m.group(1)

                f_name = ''
                if title_attr and title_attr.lower() not in IGNORED_NAMES and len(title_attr) > 2:
                    f_name = title_attr
                elif text and text.lower() not in IGNORED_NAMES and len(text) > 2:
                    f_name = text
                else:
                    f_name = clean_filename_from_url(href)

                f_name = re.sub(r'\(video\)', '', f_name, flags=re.I).strip()
                f_name = re.sub(r',\d+$', '', f_name).strip()
                f_name = clean_filename_from_url(f_name)

                thumb = ''
                if file_id and file_id in self.thumbs_by_id:
                    thumb = self.thumbs_by_id[file_id]
                elif self.last_img_thumb:
                    thumb = self.last_img_thumb

                clean_key = href.split('?')[0].split('#')[0]

                if clean_key not in self.files:
                    self.files[clean_key] = {
                        'id': file_id,
                        'name': f_name,
                        'url': href,
                        'thumb': thumb
                    }
                else:
                    curr = self.files[clean_key]['name']
                    if len(f_name) > len(curr) and f_name.lower() not in IGNORED_NAMES:
                        self.files[clean_key]['name'] = f_name
                    if not self.files[clean_key]['id'] and file_id:
                        self.files[clean_key]['id'] = file_id
                    if not self.files[clean_key].get('thumb') and thumb:
                        self.files[clean_key]['thumb'] = thumb
                return

            if href.startswith('/') and not href_lower.startswith('/action/'):
                if re.search(r',\d{4,}', href):
                    return

                clean_href = re.sub(r',\d+$', '', unquoted_href_lower)
                norm_prefix = urllib.parse.unquote_plus(self.prefix).lower()
                norm_clean = urllib.parse.unquote_plus(clean_href).lower()

                if norm_clean.startswith(norm_prefix):
                    remainder = norm_clean[len(norm_prefix):].strip('/')
                    if remainder:
                        first_seg = remainder.split('/')[0]

                        if ':' in first_seg or 'chomikuj' in first_seg.lower():
                            return
                        if any(bad in first_seg.lower() for bad in ('regulamin', 'kontakt', 'pomoc', 'oplaty')):
                            return

                        sub_path = f"{self.current_base_path}/{first_seg}"
                        folder_name = text if (text and len(text) < 70 and text.lower() not in IGNORED_NAMES) else first_seg
                        folder_name = urllib.parse.unquote(folder_name)

                        if sub_path not in self.subfolders:
                            self.subfolders[sub_path] = folder_name
                        elif text and len(text) < len(self.subfolders[sub_path]):
                            self.subfolders[sub_path] = folder_name


def list_folder(path, page=1, target_page_url=None):
    clean_path = path if path.startswith('/') else f"/{path}"
    clean_path = clean_path.rstrip('/')
    base_path = re.sub(r',\d+$', '', clean_path)

    if target_page_url:
        target_url = f"{CHOMIKUJ_URL}{target_page_url}" if target_page_url.startswith('/') else target_page_url
    elif page > 1:
        target_url = f"{CHOMIKUJ_URL}{base_path},{page}"
    else:
        target_url = f"{CHOMIKUJ_URL}{base_path}"

    xbmc.log(f"[Chomikuj] Pobieranie widoku: {target_url} (Strona {page})", xbmc.LOGINFO)

    code, html, _ = request(target_url)
    if code != 200 or not html:
        xbmcgui.Dialog().notification("Chomikuj", "Błąd ładowania folderu", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(ADDON_HANDLE)
        return

    parser = ChomikujFolderParser(base_path, page)
    parser.feed(html)

    # 1. Podfoldery
    if page == 1:
        for sub_path, name in sorted(parser.subfolders.items(), key=lambda x: x[1].lower()):
            li = xbmcgui.ListItem(label=f"📁 {name}")
            item_url = build_url({'action': 'open_folder', 'path': sub_path, 'page': '1'})
            xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=item_url, listitem=li, isFolder=True)

    # 2. Pliki wideo
    xbmcplugin.setContent(ADDON_HANDLE, 'videos')

    for f_url, info in parser.files.items():
        li = xbmcgui.ListItem(label=f"🎬 {info['name']}")
        li.setProperty('IsPlayable', 'true')
        set_item_video_info(li, info['name'])

        thumb_url = info.get('thumb')
        if not thumb_url and info.get('id') and info['id'] in parser.thumbs_by_id:
            thumb_url = parser.thumbs_by_id[info['id']]

        if thumb_url:
            ua_enc = urllib.parse.quote(USER_AGENT)
            cookie_enc = urllib.parse.quote(get_cookie_header())
            art_url = f"{thumb_url}|User-Agent={ua_enc}&Cookie={cookie_enc}"
            li.setArt({
                'thumb': art_url,
                'poster': art_url,
                'icon': art_url
            })

        play_url = build_url({
            'action': 'play',
            'file_id': info['id'] or '',
            'file_path': f_url
        })
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=play_url, listitem=li, isFolder=False)

    # 3. Następna strona
    if parser.has_next_page:
        next_page = page + 1
        next_li = xbmcgui.ListItem(label=f"➡️ Następna strona (Strona {next_page})")
        next_target = parser.next_page_url if parser.next_page_url else f"{base_path},{next_page}"
        next_url = build_url({
            'action': 'open_folder',
            'path': base_path,
            'page': str(next_page),
            'page_url': next_target
        })
        xbmcplugin.addDirectoryItem(handle=ADDON_HANDLE, url=next_url, listitem=next_li, isFolder=True)

    xbmc.log(f"[Chomikuj] Załadowano: {len(parser.subfolders)} folderów, {len(parser.files)} plików", xbmc.LOGINFO)
    xbmcplugin.endOfDirectory(ADDON_HANDLE)


def play_video(file_id, file_path):
    download_url = None
    clean_path = file_path if file_path.startswith('/') else f"/{file_path}"
    full_file_url = f"{CHOMIKUJ_URL}{clean_path}"

    if not file_id:
        m_id = re.search(r',(\d+)', clean_path)
        if m_id:
            file_id = m_id.group(1)

    xbmc.log(f"[Chomikuj] Odtwarzanie: ID={file_id}, URL={full_file_url}", xbmc.LOGINFO)

    code_p, page_html, _ = request(full_file_url, follow_redirects=True)
    token = get_verification_token(page_html) if page_html else ''

    if file_id:
        headers = {
            'X-Requested-With': 'XMLHttpRequest',
            'Referer': full_file_url,
            'Origin': CHOMIKUJ_URL,
            'Accept': 'application/json, text/javascript, */*; q=0.01'
        }
        req_url = f"{CHOMIKUJ_URL}/action/License/Download"
        payload = {
            'fileId': file_id
        }
        if token:
            payload['__RequestVerificationToken'] = token

        code_dl, resp_dl, _ = request(req_url, data=payload, headers=headers, follow_redirects=False)

        if code_dl in (301, 302, 303, 307) and resp_dl.startswith('http'):
            download_url = resp_dl
        else:
            data = {}
            try:
                data = json.loads(resp_dl)
                download_url = data.get('redirectUrl') or data.get('RedirectUrl') or data.get('Url') or data.get('url')
            except Exception:
                pass

            if not download_url:
                modal = data.get('content') or data.get('Content') or resp_dl
                if modal and ('agreement' in modal.lower() or 'pobierz' in modal.lower()):
                    form_action = req_url
                    m_act = re.search(r'action=["\']([^"\']+)["\']', modal, re.I)
                    if m_act:
                        act = m_act.group(1)
                        form_action = f"{CHOMIKUJ_URL}{act}" if act.startswith('/') else act

                    confirm_payload = {
                        'fileId': file_id,
                        'agreement': 'true',
                        'isAgreementAccepted': 'true'
                    }
                    if token:
                        confirm_payload['__RequestVerificationToken'] = token

                    for inp in re.finditer(r'name=["\']([^"\']+)["\'][^>]*value=["\']([^"\']*)["\']', modal, re.I):
                        confirm_payload[inp.group(1)] = inp.group(2)

                    code_c, resp_c, _ = request(form_action, data=confirm_payload, headers=headers, follow_redirects=False)

                    if code_c in (301, 302, 303, 307) and resp_c.startswith('http'):
                        download_url = resp_c
                    else:
                        try:
                            d_conf = json.loads(resp_c)
                            download_url = d_conf.get('redirectUrl') or d_conf.get('RedirectUrl') or d_conf.get('Url')
                        except Exception:
                            pass

    if not download_url and page_html:
        m_src = re.search(r'src=["\']([^"\']+\.(?:mp4|mkv)[^"\']*)["\']', page_html, re.I) or \
                re.search(r'file:\s*["\'](https?://[^"\']+\.(?:mp4|mkv)[^"\']*)["\']', page_html, re.I)
        if m_src:
            download_url = m_src.group(1)

    if download_url:
        if download_url.startswith('//'):
            download_url = f"https:{download_url}"

        ua = urllib.parse.quote(USER_AGENT)
        cookies = urllib.parse.quote(get_cookie_header())
        stream_url = f"{download_url}|User-Agent={ua}&Cookie={cookies}"

        play_item = xbmcgui.ListItem(path=stream_url)
        play_item.setProperty('IsPlayable', 'true')
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, True, listitem=play_item)
    else:
        xbmcgui.Dialog().notification("Chomikuj", "Nie udało się wygenerować linku", xbmcgui.NOTIFICATION_WARNING, 3500)
        xbmcplugin.setResolvedUrl(ADDON_HANDLE, False, listitem=xbmcgui.ListItem())


def router(paramstring):
    params = dict(urllib.parse.parse_qsl(paramstring))
    action = params.get('action')

    if not action:
        main_menu()
    elif action == 'set_login':
        set_credentials_dialog()
    elif action == 'open_settings':
        ADDON.openSettings()
    elif action == 'my_files':
        user = ADDON.getSetting('username')
        if not user:
            if set_credentials_dialog():
                user = ADDON.getSetting('username')
        if user:
            list_folder(f"/{user}", page=1)
    elif action == 'open_folder':
        path = params.get('path', '')
        page = int(params.get('page', 1))
        page_url = params.get('page_url')
        list_folder(path, page=page, target_page_url=page_url)
    elif action == 'play':
        file_id = params.get('file_id') or ''
        file_path = params.get('file_path') or params.get('rel_path') or ''
        play_video(file_id, file_path)


if __name__ == '__main__':
    query_string = sys.argv[2][1:] if len(sys.argv) > 2 else ""
    router(query_string)